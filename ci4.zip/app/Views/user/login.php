<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
    <div id="login-wrapper">
        <div class="container mt-5 col-5">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    LOGIN
                </div>
                <div class="card-body">
                    <?php if(session()->getFlashdata('flash_msg')):?>
                        <div class="alert alert-danger"><?=session()->getFlashdata('flash_msg') ?></div>
                    <?php endif;?>
                    <form action="" method="post">
                        <div class="mb-3">
                            <i class="fa fa-user"><i>
                            <label for="InputForEmail" class="form-label">Email Address</label>
                            <input type="email" name="email" class="form-control" id="InputForEmail" value="<?= set_value('email') ?>">
                        </div>
                        <div class="mb-3">
                            <label for="InputForPassword" class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" id="InputForPassword">
                        </div>
                        <button type="submit" class="btn btn-primary">Login</button>
                    </form>
                </div>
            </div>   
        </div>
    </div>
</body>
</html>
