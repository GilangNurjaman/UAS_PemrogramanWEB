    <footer>
        <p>&copy; 2023 - GILANG NURJAMAN - T121B1 - UNIVERSITAS PELITA BANGSA</p>
    </footer>
    </div>
</body>
</html>
