    <footer>
        <p>&copy;  2023 - GILANG NURJAMAN - TI21B1 - UNIVERSITAS PELITA BANGSA</p>
    </footer>
    </div>
</body>
</html>
